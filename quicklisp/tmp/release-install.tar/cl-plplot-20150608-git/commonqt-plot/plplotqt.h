#define PLD_qtwidget
#define PLD_extqt
#include "qt.h"
